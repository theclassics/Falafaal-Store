			</div>
		</div>
	</section>
	<section class="footer-section">
		<div class="container-fluid">
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-12">
					<div class="footer-content">
						<p>&copy; 2016 <span>falafaal.</span> Nepal's No.1 ecommerce webportal.</p>
					</div>
				</div>
			</div>
		</div>
	</section>	
</body>
</html>