<?php
 include("include/header.php");
 include("include/session.php");
?>
<div class="col-xs-12 col-sm-11 col-md-11">
	<div class="col-xs-12 col-sm-12 col-md-12 no-padding">
		<div class="main-title">
			<h3>dashboard</h3>
		</div>
	</div>
	<div class="col-xs-12 col-sm-12 col-md-12 no-padding">
		<div class="col-xs-12 col-sm-3 col-md-3 no-padding">
			<div class="panels">
				<h4>admin panel</h4>
			</div>
		</div>
		<div class="col-xs-12 col-sm-3 col-md-3 no-padding">
			<div class="panels">
				<h4>customer panel</h4>
			</div>
		</div>
		<div class="col-xs-12 col-sm-6 col-md-6 no-padding">
			<div class="panels">
				<h4>sales panel</h4>
			</div>
		</div>
		<div class="clearfix"></div>
		<div class="col-xs-12 col-sm-6 col-md-6 no-padding">
			<div class="panels">
				<h4>shops panel</h4>
			</div>
		</div>
		<div class="col-xs-12 col-sm-6 col-md-6 no-padding">
			<div class="panels">
				<h4>orders panel</h4>
			</div>
		</div>
	</div>
</div>
<?php
include("include/footer.php");
?>
