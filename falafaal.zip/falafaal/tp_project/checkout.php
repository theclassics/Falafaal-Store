<?php
    include("header.php");
    //include("session.php");
    $paypal_url = 'https://www.sandbox.paypal.com/cgi-bin/webscr'; //Test PayPal API URL
$paypal_id = 'puzzles@gmail.com'; //Business Email
    
?>
<html>
<head>
   <!-- Gumby CSS  -->
		<link rel="stylesheet" href="gumby/css/gumby.css">

		<!-- Application custom CSS -->
		<link rel="stylesheet" href="css/main.css">

</head>
<div id="index_mid" style="padding-top: 0px;">
            <div class="row">
                <div class="twelve columns">
                    
                   <table class="striped rounded">
                       
					<caption> MY CART  </caption>
					<thead>
						<tr>
                            <th>Product </th>
                            <th>Price</th>
                            <th>Quantity</th>
                            <th>Total</th>
                            <th>Grand Total</th>
						</tr>
					</thead>
					<?php
						if(isset($_SESSION["customeruser"])){
							echo "<tbody>";
							$grandtotal=0;
							if(isset($_SESSION["cart"])){
											
								
									foreach ($_SESSION["cart"] as $value) {

										$id= $value['id'];
										$pname= $value['pname'];
										$price= $value['price'];
										$qty= $value['qty'];
										$total=$price*$qty;
										$grandtotal += $total;
										
								echo "<tr>
									<td>$pname</td>
		                            <td>$$price</td>
		                            <td>$qty</td>
		                            <td>$$total</td>
		                            <td></td>
								</tr>";}
								echo "<tr>
										<td></td>
										<td></td>
										<td></td>
										<td>Grand Total:</td>
										<td>$$grandtotal</td>
									</tr>
								";
								}
							echo "</tbody>";
						}else{
							echo "<h3 style='color:red'>Please Login First</h3>";
						}
                    ?>
                        
				</table>
                    <div>
                    	
                        <form action="<?php echo $paypal_url; ?>" method="post">

        <!-- Identify your business so that you can collect the payments. -->
        <input type="hidden" name="business" value="<?php echo $paypal_id; ?>">
        
        <!-- Specify a Buy Now button. -->
        <input type="hidden" name="cmd" value="_xclick">
        
        <!-- Specify details about the item that buyers will purchase. -->
        <input type="hidden" name="item_name" value="<?php echo $pname; ?>">
        <input type="hidden" name="item_number" value="<?php echo $id; ?>">
        <input type="hidden" name="amount" value="1">
        <input type="hidden" name="quantity" value="<?php echo $qty; ?>">
        <input type="hidden" name="currency_code" value="USD">
        
        <!-- Specify URLs -->
        <input type='hidden' name='cancel_return' value='http://localhost/falafaal/tp_project/cancel.php'>
		<input type='hidden' name='return' value='http://localhost/falafaal/tp_project/success.php'>

        
        <!-- Display the payment button. -->
        <input type="image" name="submit" border="0"
        src="https://www.paypalobjects.com/en_US/i/btn/btn_buynow_LG.gif" alt="PayPal - The safer, easier way to pay online">
        <img alt="" border="0" width="1" height="1" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" >
    
    </form>
                    </div>
                </div>
                </div>
            </div>
</html>
<?php
    include("footer.php");
?>
    