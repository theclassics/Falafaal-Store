<html>
<head>
   <!-- Gumby CSS  -->
		<link rel="stylesheet" href="gumby/css/gumby.css">

		<!-- Application custom CSS -->
		<link rel="stylesheet" href="css/main.css">

</head>
<div id="footer">
    <div class="row">
        <div class="twelve columns">
            <h3> Get Your Shopping Bag In Your Door Steps !</h3>
       
    </div>
        <div>
            <ul>
                <li> <a href="#"></a> HOME </li>
                <li> ABOUT US </li>
                <li> ABOUT US </li>
                <li> ABOUT US </li>
                <li> ABOUT US </li>
            </ul>
        </div>
        
    <div>
            <br> <br> <p> &copy; falafal.com 2016 </p>
        </div>
        </div>
        
        
        </div>
</html>