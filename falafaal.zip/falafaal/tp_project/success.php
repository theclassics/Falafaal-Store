<?php
include 'connection.php';

//Store transaction information from PayPal
$item_number = $_GET['item_number']; 
$txn_id = $_GET['tx'];
$payment_gross = $_GET['amt'];
$currency_code = $_GET['cc'];
$payment_status = $_GET['st'];

//Get product price
/*$query=("SELECT PRICE FROM PRODUCTS WHERE id = ".$item_number);
$productResult = oci_parse($connection,$query) or die(oci_error());
oci_execute($productResult);
$row=oci_fetch_array($productResult);*/

//$productRow = $productResult->oci_fetch_array();
//oci_execute($productResult);
//$productPrice = $payment_gross;

/*if(!empty($txn_id) && $payment_gross == $productPrice){*/
    //Inser tansaction data into the database
    $insert =("INSERT INTO PAYMENTS(ITEM_NUMBER,TXN_ID,PAYMENT_GROSS,CURRENCY_CODE,PAYMENT_STATUS) VALUES
    ('".$item_number."','".$txn_id."','".$payment_gross."','".$currency_code."','".$payment_status."')");
	$result=oci_parse($connection, $insert);
	oci_execute($result) or die(oci_error());
    //$last_insert_id = $connection->insert_id;
?>
	<h1>Your payment has been successful.</h1>
    <h1>Your Payment ID </h1>
<?php
//}else{
?>
	
<?php
//}
?>