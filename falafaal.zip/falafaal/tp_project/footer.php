<html>
<head>
   <!-- Gumby CSS  -->
		<link rel="stylesheet" href="gumby/css/gumby.css">

		<!-- Application custom CSS -->
		<link rel="stylesheet" href="css/main.css">

</head>
<div id="footer">
    <div class="row">
        <div class="twelve columns">
            <div class="four columns"> 
            <h4> Shops </h4>
            <ul>
                <li> <a href="#"> BUCHERS</a>  </li>
                <li> <a href="#">GREENGROCER </a> </li>
                <li> <a href="#"> FISHMONGER</a> </li>
                <li> <a href="#"> BAKERY </a> </li>
                <li> <a href="#"> DELICATESSEN </a> </li>
            </ul>
        </div>
        <div class="four columns"> 
            <h4> New Products </h4>
            <ul>
                <li> <a href="#"> product 1</a>  </li>
                <li> <a href="#">product 1 </a> </li>
                <li> <a href="#"> product 1</a> </li>
                <li> <a href="#"> product 1</a> </li>
               
            </ul>
        </div>
            <div class="four columns">
                <a href="www.facebook.com"> <img height="50px" width="50px" src="images/facebook.jpeg"> </a>
                 <a href="www.youtube.com"> <img height="50px" width="50px" src="images/youtube-logo-04.jpg"> </a>
                
            </div>
       
    </div>
    <div>
            <br> <br> <p> &copy; falafal.com 2016 </p>
        </div>
        </div>
        
        
        </div>
</html>