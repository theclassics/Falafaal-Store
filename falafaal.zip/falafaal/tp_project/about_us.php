<?php
    include("header.php");
    //include("session.php");
?>
<html>
<head>
   <!-- Gumby CSS  -->
		<link rel="stylesheet" href="gumby/css/gumby.css">

		<!-- Application custom CSS -->
		<link rel="stylesheet" href="css/main.css">

</head>
<div>
    <div class="row">
        <div class="twelve columns">
            <div>
                <p> falafal.com sma kdakl dksakd kad kadjss</p>
            </div>
            <h4> VISIT US  </h4>
            <img src="images/map.jpg" height="600px" width="1000px" />
            <div>
                <h4> ABOUT US </h4>
                <i> falafal.com is an online website that functions with an objective to provide the user's daily house hold items. currently we have been operating the webpage with limited 
                traders. all of the products are uniquely identified with a unique ID. however, the company has yet to provide delivery service to the users. in the up-comming days falafal promises to incude a home delivery inside kathmandu valley. </i> <br> <br> <br> <br>
                <h4> </h4>
            </div>
           
        
        </div>
    </div>
    </div>
</html>
<?php
    include("footer.php");
?>